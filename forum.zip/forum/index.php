<?php
  session_start();
  require("partials/_connection.php");
require("partials/_header.php");

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
  <?php
  if(isset($_SESSION['signup'])){
    $ch = $_GET['ch'];
    if($ch == 1){
      session_unset();
      session_destroy();
      echo'<div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
      <strong>Success!</strong> Now, You can login.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    elseif($ch == 3){
      session_unset();
      session_destroy();
      echo'<div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
      <strong>Error!</strong> This email already in use.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    elseif($ch == 5){
      session_unset();
      session_destroy();
      echo'<div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
      <strong>Error!</strong> Passwords do not match.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    elseif($ch == 6){
      session_unset();
      session_destroy();
      echo'<div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
      <strong>Error!</strong> Invalid Credentials.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
    elseif($ch == 7){
      session_unset();
      session_destroy();
      echo'<div class="alert alert-warning alert-dismissible fade show my-0" role="alert">
      <strong>Successfully!</strong> Logged out.
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      </div>';
    }
  }
  ?>
    <!-- slider -->
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/1.jpeg" class="d-block w-100" alt="..." width="100%" height="500">
    </div>
    <div class="carousel-item">
      <img src="images/2.jpg" class="d-block w-100" alt="..." width="100%" height="500">
    </div>
    <div class="carousel-item">
      <img src="images/3.jpg" class="d-block w-100" alt="..." width="100%" height="500">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>



    <h1 class="text-center my-4">iDiscuss - Browse Categories</h1>

    <div class="container">


        <div class="row">
            <?php
            $var = 0;
            $sql = "SELECT * FROM categories";
            $res = mysqli_query($conn, $sql);;
            while($data = mysqli_fetch_assoc($res)){
                $var++;
               $name = $data['category_name'];
               $id = $data['category_id'];
               $desc = $data['category_desc'];
              echo ' <div class="col-md-4">
              <div class="card my-3" style="width: 18rem;">
                  <img src="images/pic'.$var.'.png" class="card-img-top" alt="Picture" width="500" height="240">
                  <div class="card-body">
                      <h5 class="card-title"><a href="threadlist.php? catid='.$id.'"> '.$name.' </a></h5>
                      <p class="card-text"> '.substr($desc, 0,100).'... </p>
                      <a href="threadlist.php? catid='.$id.'" class="btn btn-primary">View Thread</a>
                  </div>
              </div>
          </div>';
            }

            ?>
        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>

<?php
include("partials/_footer.php");
?>