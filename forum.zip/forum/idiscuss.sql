-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 03, 2023 at 06:45 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `idiscuss`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `category_desc` text NOT NULL,
  `created_on` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_desc`, `created_on`) VALUES
(1, 'JavaScript ', 'JavaScript (JS) is a lightweight, interpreted, or just-in-time compiled programming language with first-class functions.', '2023-05-01 10:22:30'),
(2, 'PHP', 'PHP is a general-purpose scripting language geared toward web development. It was originally created by Danish-Canadian programmer Rasmus Lerdorf in 1993 and released in 1995. The PHP reference implementation is now produced by The PHP Group.', '2023-05-01 10:24:26'),
(3, 'Python', 'Python is a high-level, general-purpose programming language. Its design philosophy emphasizes code readability with the use of significant indentation via the off-side rule. Python is dynamically typed and garbage-collected.', '2023-05-01 12:00:31'),
(4, 'C++', 'C++ is a high-level, general-purpose programming language created by Danish computer scientist Bjarne Stroustrup.', '2023-05-01 12:01:49'),
(5, 'Ruby', 'Ruby is an interpreted, high-level, general-purpose programming language which supports multiple programming paradigms. It was designed with an emphasis on programming productivity and simplicity. In Ruby, everything is an object, including primitive data types.', '2023-05-01 12:08:40');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `comment_content` text NOT NULL,
  `thread_id` int(11) NOT NULL,
  `comment_by` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `comment_content`, `thread_id`, `comment_by`, `time`) VALUES
(1, 'This is a first reply. I am stocked in a problem, please help me to solve a problem.', 1, 1, '2023-05-02 11:20:01'),
(2, 'This is the second reply to this problem...', 1, 2, '2023-05-02 11:41:09'),
(3, 'hello', 5, 3, '2023-05-02 11:42:53'),
(4, '22 years bro', 18, 4, '2023-05-03 18:27:53'),
(5, '22 years bro', 18, 5, '2023-05-03 18:27:58'),
(6, 'OOH bro its very simple...', 20, 6, '2023-05-04 09:41:51'),
(7, 'OOH bro its very simple...', 20, 6, '2023-05-04 09:41:55'),
(8, 'OOH bro its very simple...', 20, 6, '2023-05-04 09:42:00'),
(9, '22 years', 19, 2, '2023-05-09 11:05:18'),
(10, 'Khatro ka khilardi', 19, 2, '2023-05-09 11:36:01'),
(11, '&lt;script&gt;alert(\"hello\");&lt;/script&gt;', 1, 2, '2023-05-09 11:39:35'),
(12, 'okay', 21, 2, '2023-05-09 14:57:33'),
(13, 'ghdfghfhdh', 4, 7, '2023-07-18 10:11:16');

-- --------------------------------------------------------

--
-- Table structure for table `thread`
--

CREATE TABLE `thread` (
  `thread_id` int(11) NOT NULL,
  `thread_tittle` varchar(255) NOT NULL,
  `thread_desc` text NOT NULL,
  `thread_cat_id` int(11) NOT NULL,
  `thread_user_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thread`
--

INSERT INTO `thread` (`thread_id`, `thread_tittle`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `time`) VALUES
(1, 'Unable to use PHP is web.', 'I am stocked in a problem, please help me to solve a problem.', 2, 1, '2023-05-01 15:09:35'),
(2, 'Facing error while using fopen function.', 'Please help me in solving this issue \"Facing error while using fopen function.\", please tell me how to use this function.', 2, 2, '2023-05-01 15:25:23'),
(3, 'tittle of problem', 'description of your problem', 4, 3, '2023-05-01 17:54:01'),
(4, 'tittle of problem', 'description of your problem', 1, 4, '2023-05-01 17:57:03'),
(5, 'tittle of problem', 'des', 1, 5, '2023-05-01 18:07:41'),
(6, 'tittle of problem', 'Description', 1, 1, '2023-05-01 18:08:56'),
(7, 'tittle of problem', 'Description', 1, 2, '2023-05-01 18:13:12'),
(8, 'tittle of problem', 'Description', 1, 3, '2023-05-01 18:14:13'),
(9, 'tittle of problem', 'Description', 1, 3, '2023-05-01 18:15:39'),
(10, 'tittle of problem', 'Description', 1, 4, '2023-05-01 18:16:14'),
(11, 'tittle of problem', 'Description', 1, 5, '2023-05-01 18:17:04'),
(12, 'tittle of problem', 'descttt', 1, 1, '2023-05-01 18:17:16'),
(13, 'tittle of problem', 'descttt', 1, 2, '2023-05-01 18:18:29'),
(14, 'Python problem', 'describe python problem.', 3, 4, '2023-05-01 18:26:23'),
(15, 'Python problem', 'describe python problem.', 3, 3, '2023-05-01 18:26:31'),
(16, 'I have question', 'this is my question\r\n', 2, 4, '2023-05-03 18:24:16'),
(17, 'I have question', 'this is my question\r\n', 2, 5, '2023-05-03 18:24:26'),
(18, 'Max age of punjab police', 'answer please', 2, 1, '2023-05-03 18:27:28'),
(19, 'Max age of punjab police', 'answer please', 2, 5, '2023-05-03 18:27:33'),
(20, 'I have question', 'PHP is a general-purpose scripting language geared toward web development. It was originally created by Danish-Canadian programmer Rasmus Lerdorf in 1993 and released in 1995. The PHP reference implementation is now produced by The PHP Group.', 2, 6, '2023-05-04 09:40:57'),
(21, 'I have question', 'PHP is a general-purpose scripting language geared toward web development. It was originally created by Danish-Canadian programmer Rasmus Lerdorf in 1993 and released in 1995. The PHP reference implementation is now produced by The PHP Group.', 2, 6, '2023-05-04 09:41:14'),
(22, 'tittle of problem', 'answer please...', 5, 2, '2023-05-04 11:03:48'),
(23, 'tittle of problem', 'answer please...', 5, 2, '2023-05-04 11:03:56'),
(24, 'tittle of problem', 'answer please...', 5, 2, '2023-05-04 11:03:58'),
(25, 'tittle of problem', 'answer please...', 5, 2, '2023-05-04 11:05:21'),
(26, 'tittle of problem', 'answer please...', 5, 2, '2023-05-04 11:05:54'),
(27, 'hello', 'yes', 5, 2, '2023-05-04 11:08:05'),
(28, 'hello', 'yes', 5, 2, '2023-05-04 11:08:47'),
(29, 'hello', 'yes', 5, 2, '2023-05-04 11:08:54'),
(30, 'hello', 'yes', 5, 2, '2023-05-04 11:11:40'),
(31, 'hello', 'yes', 5, 2, '2023-05-04 11:11:46'),
(32, 'hello', 'yes', 5, 2, '2023-05-04 11:11:47'),
(33, 'hello', 'yes', 5, 2, '2023-05-04 11:11:48'),
(34, '&lt;script&gt;alert(\"hello\");&lt;/script&gt;', '&lt;script&gt;alert(\"hello\");&lt;/script&gt;', 2, 2, '2023-05-09 11:36:58'),
(35, 'What is python', 'please tell me what is python....', 3, 2, '2023-05-11 09:26:47'),
(36, 'What is python', 'please tell me what is python....', 3, 2, '2023-05-11 09:27:50'),
(37, 'Max age of punjab police', 'ans plz', 1, 7, '2023-07-18 10:10:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Sno` int(11) NOT NULL,
  `email` varchar(45) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(256) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Sno`, `email`, `name`, `password`, `time`) VALUES
(2, 'aliusmangouhar@gmail.com', 'Ali Usman', '$2y$10$YGh4TyyxqekA8lwQr/yKA.aqYku0ZDJT/Xw63j7lsvpnRe36Hu5ge', '2023-05-02 18:20:17'),
(3, 'aliusmangouhar1@gmail.com', 'Ali Gouhar', '$2y$10$kTjeQ5hoilV6tMR8rJkfN.S.mtfXnZHg7iRUddb6ai4C2pHzpjE/O', '2023-05-03 08:22:46'),
(4, 'aliusmangouhar2@gmail.com', 'Usman Gouhar', '$2y$10$XJMxzUqIGh.gQ6QFOTc4gu82pfEObcJsc5dkWAwVTEK/TC.N7OMIq', '2023-05-03 08:29:41'),
(5, 'aliusmangouhar3@gmail.com', 'Usman Sial', '$2y$10$bSeoApBw/xaCy0FTZqUX5Oz8PpEOg1Igz3R9r67.C1PM1uMHOelRO', '2023-05-03 08:34:17'),
(6, 'aliusmangouhar5@gmail.com', 'Ali Usman Gouhar', '$2y$10$a1cVu6.Fa6QZ4QjjTUu/Aeq3YyIIl0Ie.seOwqM44ffChZzOztIUW', '2023-05-04 09:26:17'),
(7, 'aliusmangouhar51@gmail.com', 'Ali Usman', '$2y$10$I9fpzpuQkiqbxL3tEoCQtu42bZ5nC/MRopNOIKR4Mt4h03yqSweBG', '2023-07-18 10:09:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `thread`
--
ALTER TABLE `thread`
  ADD PRIMARY KEY (`thread_id`);
ALTER TABLE `thread` ADD FULLTEXT KEY `thread_tittle` (`thread_tittle`,`thread_desc`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `thread`
--
ALTER TABLE `thread`
  MODIFY `thread_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `Sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
