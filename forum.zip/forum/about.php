<?php
require("partials/_header.php");
require("partials/_connection.php");

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>


<div class="container">



<main>

  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">Ali Usman Gouhar Sial</h1>
        <p class="lead text-muted" align="justify">Certainly! A coder, also known as a programmer or developer, is an individual who specializes in writing computer programs using programming languages. Coders are skilled in translating concepts and ideas into instructions that computers can understand and execute. They work on various software development projects, ranging from simple scripts to complex applications and systems.</p>
      </div>
    </div>
  </section>

  <div class="album py-5 bg-light">
    <div class="container">

      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
          <div class="card shadow-sm">
           <img src="images/pict1.png" alt="Picture" width="100%" height="225">

            <div class="card-body">
              <p class="card-text" align="justify">Coders are proficient in programming languages such as Python, Java, C++, JavaScript, and many others. They use these languages to write code, which is a set of instructions that define how a program should behave. They also utilize development tools, frameworks, and libraries to streamline the coding process and enhance efficiency.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">3 days</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img src="images/pict3.png" alt="Picture" width="100%" height="225">

            <div class="card-body">
            <p class="card-text" align="justify">In addition to writing code, coders are responsible for debugging and testing their programs to ensure they function correctly and meet the desired requirements. They often collaborate with other team members, such as software engineers, designers, and project managers, to develop and deploy software applications.</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">4 hours</small>
              </div>
            </div>
          </div>
        </div>
        <div class="col">
          <div class="card shadow-sm">
          <img src="images/pict4.jpg" alt="Picture" width="100%" height="225">
            <div class="card-body">
            <p class="card-text" align="justify">Coders are continuously learning and staying updated with new technologies, programming languages, and industry best practices. They may specialize in specific areas of coding, such as web development, mobile app development, data analysis, artificial intelligence, or cybersecurity, among others......</p>
              <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                  <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                  <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                </div>
                <small class="text-muted">5 mins</small>
              </div>
            </div>
          </div>
        </div>

       

</main>



</div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>

<?php
include("partials/_footer.php");
?>