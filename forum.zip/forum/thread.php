<?php
  session_start();
  require("partials/_connection.php");
require("partials/_header.php");


?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="container my-5">
        <?php
    $id = $_GET['catid'];
    $uid = $_GET['uid'];
     $sql = "SELECT * FROM thread WHERE thread_id = '$id'";
     $res = mysqli_query($conn, $sql);
     $noresult = true;
     while($data = mysqli_fetch_assoc($res)){
        $noresult = false;
        $title = $data['thread_tittle'];
        $thread_desc = $data['thread_desc'];
        $time = $data['time'];
        $sql2 = "SELECT name FROM users WHERE Sno='$uid'";
            $res2 = mysqli_query($conn, $sql2);
            $get = mysqli_fetch_assoc($res2);
            $name = $get['name'];
    echo '<div class="p-5 mb-4 bg-light rounded-3" width="800">
    <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">'.$title.'</h1>
        <p class="fs-4" align="justify">'.$thread_desc.'</p>
        <hr>
        <p class="col-md-8">
        <h4>Rules</h4>
        No Spam / Advertising / Self-promote in the forums.
        Do not post copyright-infringing material.
        Do not post “offensive” posts, links or images.
        Do not cross post questions.
        Remain respectful of other members at all times.</p>
          <hr>
        <p>Posted by: <b>'.$name.'</b></p>
    </div>
</div>';}


if($noresult){
    echo '<div class="p-5 mb-4 bg-light rounded-3" width="800">
    <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">No Threads Found</h1>
        <hr>
    </div>
</div>';
 }
    ?>
 <h1 class="fw-bold">Replies to this problem</h1><br>
<div class="row align-items-md-stretch">
            <div class="col-md-6">
                <div class="h-100 p-5 text-bg-light border rounded-3">
                    <?php     
                        $sql = "SELECT * FROM comments WHERE thread_id = '$id'";
                        $res = mysqli_query($conn, $sql);
                        $noresult = true;
                        while($data = mysqli_fetch_assoc($res)){
                            $noresult = false;
                            $content = $data['comment_content'];
                            $comment_by = $data['comment_by'];
                            $sql2 = "SELECT name FROM users WHERE Sno='$comment_by'";
                            $res2 = mysqli_query($conn, $sql2);
                            $get = mysqli_fetch_assoc($res2);
                            $name = $get['name'];
                            echo '    <div class="d-flex my-4">
                            <div class="flex-shrink-0">
                                <img src="images/user.png" alt="Picture" width="90px">
                            </div>
                            <div class="flex-grow-1 ms-3">
                            <div class="d-flex div1">
                            <h6 class="my-0">'.$name.'</h6>
                            <p class="my-0 text-align-right">'.$time.'</p>
                            </div>
                            <hr class="my-0">
                                '.$content.'<br>
                            </div>
                        </div>';
                        }

                        if($noresult){
                            echo '<div class="p-5 mb-4 bg-light rounded-3" width="800">
                            <div class="container-fluid py-5">
                                <h1 class="display-5 fw-bold">No replies yet...</h1>
                                <p class="fs-4" align="justify">Be the first one to answer a problem.</p>
                                <hr>
                            </div>
                        </div>';
                        }

        ?>



                </div>
            </div>
            <div class="col-md-6">
                <div class="h-100 p-5 bg-light border rounded-3">

                <?php
                    if(isset($_SESSION['email'])){
                    if(isset($_SESSION['login']))
                    {
                    echo '<h1 class="text-center">Post Comment</h1>

                    <form action="'. $_SERVER['REQUEST_URI'] .'" method="post">
                        <div class="mb-3">
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Comment</label>
                                <textarea class="form-control" aria-label="With textarea" id="comment"
                                    name="comment"></textarea>
                            </div>
                            <div id="emailHelp" class="form-text">Please post helping material only</div>
                        </div>

                        <button type="submit" class="btn btn-primary">Post Comment</button>
                    </form>';
                    }
                    }
                    else
                    {
                        echo '<div class="p-5 mb-4 bg-light rounded-3 text-center" width="800">
                        <div class="container-fluid py-5">
                            <h1 class="display-5 fw-bold text-center">Post Comment</h1>
                            <p class="fs-4 text-center " align="justify">Please login to post any comment.</p>
                            <hr>
                        </div>
                    </div>';
                    }
                    ?>

                    <?php
                         $checkr = false;
                        if($_SERVER['REQUEST_METHOD']=='POST'){
                            $com = $_POST['comment'];
                            $com = str_replace("<", "&lt;", $com);
                            $com = str_replace(">", "&gt;", $com);
                            $thread_user_id = $_SESSION['sno'];
                            $sqli="INSERT INTO `comments` (`comment_content`, `thread_id`, `comment_by`, `time`) VALUES ('$com', '$id', '$thread_user_id', current_timestamp())";
                            $res1 = mysqli_query($conn, $sqli);
                            if($res1){
                                $checkr = true;
                            }
                    }
                    ?>
                    <?php
if($checkr)
echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
<strong>Success!</strong> Your thread uploaded.
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
    ?>

                </div>
            </div>
        </div>





       
        <br>
        <!-- <div class="row align-items-md-stretch">
            <div class="col-md-6">
                <div class="h-100 p-5 text-bg-light border rounded-3">
                    <?php
                    $sql = "SELECT * FROM thread WHERE thread_cat_id = '$id'";
                    $res = mysqli_query($conn, $sql);;
                    while($data = mysqli_fetch_assoc($res)){
                        $title = $data['thread_tittle'];
                        $thread_desc = $data['thread_desc'];
                        echo '    <div class="d-flex my-4">
                        <div class="flex-shrink-0">
                            <img src="images/user.png" alt="Picyure" width="90px">
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h4>'.$title.'</h4>
                            '.$thread_desc.'<br>
                            <a href="#" class="stretched-link">Read Thread</a>
                            <hr>
                        </div>
                    </div>';
                    }
        ?> -->


        </div>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
        </script>
</body>

</html>

<?php
include("partials/_footer.php");
?>