<?php
  session_start();
  require("partials/_connection.php");
require("partials/_header.php");

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>iDiscuss</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <style>
    .div2 {
        margin-left: auto;
        margin-right: auto;
        max-width: 75%;
        min-height: 307px;
    }

    .head {
        text-decoration: none;
        color: black;
        font-weight: bold;
        font-size: 25px;
    }
    </style>

</head>

<body>

    <div class="div2">
        <?php
$qry = $_GET['search'];
$chech = true;

    echo '<h1>Showing results for \''.$qry.'\'</h1>';

    $sql = "SELECT * FROM thread WHERE MATCH (thread_tittle, thread_desc) AGAINST ('$qry')";
    $res = mysqli_query($conn, $sql);
    while($data = mysqli_fetch_assoc($res)){
        $chech = false;
        $title = $data['thread_tittle'];
        $thread_desc = $data['thread_desc'];
        $thread_id = $data['thread_id'];
        $hltext1 = preg_replace('/(' .preg_quote($qry, '/') . ')/i', '<span style="background-color: yellow;">$1</span>', $title);
        $hltext2 = preg_replace('/(' .preg_quote($qry, '/') . ')/i', '<span style="background-color: yellow;">$1</span>', $thread_desc);
        $sql2 = "SELECT thread_user_id FROM thread WHERE thread_id = '$thread_id'";
        $res2 = mysqli_query($conn, $sql2);
        $data2 = mysqli_fetch_assoc($res2);
        $get2 = $data2['thread_user_id'];
    echo '
    <div class="bg-light rounded-3" width="800">
    <div class="container-fluid py-0">
        <h1><a class="head" href="thread.php? catid='.$thread_id.' & uid='.$get2.'"><b>'.$hltext1.'</b></a></h1>
        <p class="fs-4" align="justify">'.$hltext2.'</p>
</div>
</div>

';
}
if($chech){
    echo '<div class="p-5 mb-4 bg-light rounded-3 text-center" width="800">
        <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold text-center">No results found for '.$qry.'</h1>
        <p class="fs-4 text-center " align="justify">Search different query to get results!</p>
        <hr>
        </div>
        </div>';
}
?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>

<?php
include("partials/_footer.php");
?>