<?php
  session_start();
  require("partials/_connection.php");
require("partials/_header.php");

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Threads</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <link rel="stylesheet" href="style.css">
</head>

<body>

    <div class="container my-5">
        <?php
    $id = $_GET['catid'];
     $sql = "SELECT * FROM categories WHERE category_id = '$id'";
     $res = mysqli_query($conn, $sql);
     while($data = mysqli_fetch_assoc($res)){
        $name = $data['category_name'];
        $desc = $data['category_desc'];
    echo '<div class="p-5 mb-4 bg-light rounded-3" width="800">
    <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold">Welcome to '.$name.' forums</h1>
        <p class="fs-4" align="justify">'.$desc.'</p>
        <hr>
        <p class="col-md-8">
        <h4>Rules</h4>
        No Spam / Advertising / Self-promote in the forums.<br>
        Do not post copyright-infringing material.<br>
        Do not post “offensive” posts, links or images.<br>
        Do not cross post questions.<br>
        Remain respectful of other members at all times.<br></p>
    </div>
</div>';}

    ?>




        <h1>Browse Questions</h1>
        <br>
        <div class="row align-items-md-stretch">
            <div class="col-md-6">
                <div class="h-100 p-5 text-bg-light border rounded-3">
                    <?php     
                        $sql = "SELECT * FROM thread WHERE thread_cat_id = '$id'";
                        $res = mysqli_query($conn, $sql);
                        $noresult = true;
                        while($data = mysqli_fetch_assoc($res)){
                            $noresult = false;
                            $idi = $data['thread_id'];
                            $user_id = $data['thread_user_id'];
                            $title = $data['thread_tittle'];
                            $thread_desc = $data['thread_desc'];
                            $time = $data['time'];
                            $sql2 = "SELECT name FROM users WHERE Sno='$user_id'";
                            $res2 = mysqli_query($conn, $sql2);
                            $get = mysqli_fetch_assoc($res2);
                            $name = $get['name'];
                            echo '    <div class="d-flex my-4">
                            <div class="flex-shrink-0">
                                <img src="images/user.png" alt="Picture" width="90px">
                            </div>
                            <div class="flex-grow-1 ms-3">
                            <div class="d-flex div1">
                            <h6 class="my-0">'.$name.'</h6>
                            <p class="my-0 text-align-right">'.$time.'</p>
                            </div>
                            <hr class="my-0">
                                <h4>'.$title.'</h4>
                                '.$thread_desc.'<br>
                               <a href="thread.php? catid='.$idi.' & uid='.$user_id.'">Read Thread</a>
                            </div>
                        </div>';
                        }

                        if($noresult){
                            echo '<div class="p-5 mb-4 bg-light rounded-3" width="800">
                            <div class="container-fluid py-5">
                                <h1 class="display-5 fw-bold">No Threads Found</h1>
                                <p class="fs-4" align="justify">Be the first person to ask a question.</p>
                                <hr>
                            </div>
                        </div>';
                        }

        ?>



                </div>
            </div>
            <div class="col-md-6">
                <div class="h-100 p-5 bg-light border rounded-3">

                    <?php
                    if(isset($_SESSION['email'])){
                    if(isset($_SESSION['login']))
                    {
                    echo '<h1 class="text-center fw-bold">Ask any query</h1>
                    <form action="'.$_SERVER['REQUEST_URI'] .'" method="post">
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Problem Tittle</label>
                            <input type="text" class="form-control" id="tittle" name="tittle"
                                aria-describedby="emailHelp">
                            <div id="emailHelp" class="form-text">Enter a short tittle of your problem.</div>
                        </div>
                        <div class="mb-3">
                            <div>
                                <label for="exampleInputEmail1" class="form-label">Discuss problem</label>
                                <textarea class="form-control" aria-label="With textarea" id="desc"
                                    name="desc"></textarea>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>';
                    }
                    }
                    else
                    {
                        echo '<div class="p-5 mb-4 bg-light rounded-3 text-center" width="800">
                        <div class="container-fluid py-5">
                            <h1 class="display-5 fw-bold text-center">Ask any query</h1>
                            <p class="fs-4 text-center " align="justify">Please login to ask a question.</p>
                            <hr>
                        </div>
                    </div>';
                    }
                    
                         $checkr = false;
                        if($_SERVER['REQUEST_METHOD']=='POST'){
                            $tit = $_POST['tittle'];
                            $desc = $_POST['desc'];
                            $tit = str_replace("<", "&lt;", $tit);
                            $tit = str_replace(">", "&gt;", $tit);
                            $desc = str_replace("<", "&lt;", $desc);
                            $desc = str_replace(">", "&gt;", $desc);
                            $thread_user_id = $_SESSION['sno'];
                            $sqli="INSERT INTO `thread` (`thread_tittle`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `time`) VALUES ('$tit', '$desc', '$id', '$thread_user_id', current_timestamp())";
                            $res1 = mysqli_query($conn, $sqli);
                            if($res1){
                                $checkr = true;
                            }
                    }
                    ?>
                    <?php
if($checkr)
echo '<div class="alert alert-warning alert-dismissible fade show" role="alert">
<strong>Success!</strong> Your thread uploaded.
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
    ?>

                </div>
            </div>
        </div>


    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>

<?php
include("partials/_footer.php");
?>