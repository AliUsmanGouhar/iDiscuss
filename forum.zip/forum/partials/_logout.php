<?php
session_start();
session_unset();
session_destroy();
session_start();
$_SESSION['signup']=0;
header("location: /forum/index.php? ch=7");
exit;
?>