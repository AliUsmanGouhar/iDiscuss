<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <span class="align-bottom">

        <div class="b-example-divider"></div>
        <div class="bg-dark text-secondary px-4 py-5 text-center">
            <div class="py-5">
                <h1 class="display-5 fw-bold text-white">iDiscuss with Ali Usman Gouhar</h1>
                <div class="col-lg-6 mx-auto">
                    <p class="fs-5 mb-4">Here you can ask any query, Experts will answer you in short period of time.
                    </p>
                   
                    <script>
                     function check(){
                     return confirm("Are you sure, you want to Logout!");
                    }
                </script>
                <?php
                if(isset($_SESSION['email'])){
                    if(isset($_SESSION['login']))
                    {
                        echo 'Hello <b>'.$_SESSION['name'].'</b>, click here to &nbsp';
                        echo '<a href="/forum/partials/_logout.php" onclick="return check()">Logout</a>';
                    }
                }
                else{
                echo ' <div class="d-grid gap-2 d-sm-flex justify-content-sm-center">
                <button type="button" class="btn btn-outline-info btn-lg px-4 me-sm-3 fw-bold"
                    data-bs-toggle="modal" data-bs-target="#loginmodal">Login</button>
                <button type="button" class="btn btn-outline-light btn-lg px-4" data-bs-toggle="modal"
                    data-bs-target="#signupmodal">Signup</button>
            </div>';
                }
                ?>
                </div>
            </div>
        </div>
    </span>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>
<?php
include("partials/_loginmodal.php");
include("partials/_signupmodal.php");
?>