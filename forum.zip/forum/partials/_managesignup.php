<?php
session_start();
  $checkr = 0;
  $ch = 2;
  $chpass = 4;
  if($_SERVER['REQUEST_METHOD']=='POST'){
    require("_connection.php");
      $email = $_POST['email'];
      $name = $_POST['name'];
      $pass = $_POST['pass'];
      $cpass = $_POST['cpass'];
      if($pass == $cpass){
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $res = mysqli_query($conn, $sql);
        $rows = mysqli_num_rows($res);
        if($rows<1){
        $hash = password_hash($pass, PASSWORD_DEFAULT);
      $sqli="INSERT INTO `users` (`email`, `name`, `password`, `time`) VALUES ('$email', '$name', '$hash', current_timestamp())";
      $res1 = mysqli_query($conn, $sqli);
      if($res1){
          $checkr = 1;
          $_SESSION['signup']=1;
          header("location: /forum/index.php? ch=$checkr");
      }
      }
      else
      {
        $ch = 3;
        $_SESSION['signup']=0;
        header("location: /forum/index.php? ch=$ch");
      }           
    }
    else
    {
        $chpass = 5;
        $_SESSION['signup']=0;
        header("location: /forum/index.php? ch=$chpass");
    }

}

?>