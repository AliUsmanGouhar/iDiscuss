<?php
session_start();
  $checkr = 0;
  if($_SERVER['REQUEST_METHOD']=='POST'){
    require("_connection.php");
      $email = $_POST['email'];
      $pass = $_POST['pass'];
        $sql = "SELECT * FROM users WHERE email = '$email'";
        $res = mysqli_query($conn, $sql);
        $rows = mysqli_num_rows($res);
        if($rows==1){
            $get = mysqli_fetch_assoc($res);
            $pwd = $get['password'];
            $hash = password_verify($pass, $pwd);
            if($hash)
            {
                $_SESSION['email'] = $get['email'];
                $_SESSION['name'] = $get['name'];
                $_SESSION['sno'] = $get['Sno'];
                $_SESSION['login'] = true;
                $chechr = 6;
                header("location: /forum/index.php");
            }
            else
            {
                $chechr = 6;
                $_SESSION['signup']=0;
                header("location: /forum/index.php? ch=$chechr");
            }
      }
      else
      {
        $chechr = 6;
        $_SESSION['signup']=0;
        header("location: /forum/index.php? ch=$chechr");
      }           
    }
   
?>