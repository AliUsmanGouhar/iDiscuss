<!-- INSERT INTO `categories` (`category_id`, `category_name`, `category_desc`, `created_on`) VALUES (NULL, 'JavaScript ', 'JavaScript (JS) is a lightweight, interpreted, or just-in-time compiled programming language with first-class functions.', current_timestamp());-->

<!-- INSERT INTO `thread` (`thread_id`, `thread_tittle`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `time`) VALUES (NULL, 'Facing error while using fopen function.', 'Please help me in solving this issue \"Facing error while using fopen function.\", please tell me how to use this function.', '2', '0', current_timestamp()); -->
<!-- INSERT INTO `comments` (`comment_id`, `comment_content`, `thread_id`, `comment_by`, `time`) VALUES ('1', 'This is a first reply', '1', '0', current_timestamp()); -->


<?php

$SN = "localhost";
$UN = "root";
$PW = "";
$DB = "idiscuss";

$conn = mysqli_connect($SN, $UN, $PW, $DB);

if($conn){
    // echo "Successfull";
}
else{
    echo "Error".mysqli_connect_error();
}


?>